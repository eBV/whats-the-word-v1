import { useState, useEffect } from 'react';
import { PROMPTS } from '../prompts';
import { useSpacetime } from '../spacetime';
import { Send, Lock, Globe } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

export default function Home() {
  const { stats, submitWord } = useSpacetime();
  const [prompt, setPrompt] = useState('');
  const [promptIndex, setPromptIndex] = useState(0);
  const [word, setWord] = useState('');
  const [isPublic, setIsPublic] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    // Pick a random prompt on mount
    const idx = Math.floor(Math.random() * PROMPTS.length);
    setPrompt(PROMPTS[idx]);
    setPromptIndex(idx);
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!word.trim()) return;

    try {
      setIsSubmitting(true);
      await submitWord(word.trim(), isPublic, promptIndex);
      setWord('');

      const idx = Math.floor(Math.random() * PROMPTS.length);
      setPrompt(PROMPTS[idx]);
      setPromptIndex(idx);

    } catch (error) {
      console.error(error);
    } finally {
      setIsSubmitting(false);
    }
  };

  const isLimitReached = stats.dailyCount >= 20;

  return (
    <div className="flex flex-col items-center px-6 pt-12 pb-4 h-full">
      {/* Title */}
      <h1 className="text-3xl font-extrabold tracking-tight text-farcaster-900 mb-10 font-sans text-center leading-tight">
        WHAT'S THE<br />WORD?
      </h1>

      {/* Main Circle Icon */}
      <div className="mb-10 relative">
        <div className="w-32 h-32 rounded-full bg-farcaster-100 flex items-center justify-center shadow-inner relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-tr from-farcaster-200 to-transparent opacity-50" />
          <span className="text-8xl text-farcaster-600 font-sans font-extrabold z-10 pt-2 shadow-sm">?</span>
        </div>
        {/* Daily Counter (only if >= 15) */}
        {stats.dailyCount >= 15 && !isLimitReached && (
          <div className="absolute -bottom-2 -right-2 bg-farcaster-600 text-white text-xs font-bold px-2 py-1 rounded-lg shadow-md border border-white">
            {stats.dailyCount}/20
          </div>
        )}
      </div>

      <AnimatePresence mode="wait">
        {isLimitReached ? (
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="text-center mt-8 p-8 bg-white rounded-2xl shadow-sm border border-farcaster-100 max-w-xs"
          >
            <h3 className="text-xl font-bold text-farcaster-800 mb-2">You've shared your 20 words today!</h3>
            <p className="text-farcaster-600">Come back tomorrow for new prompts.</p>
          </motion.div>
        ) : (
          <motion.div
            key="input-area"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="w-full max-w-xs space-y-6"
          >
            {/* Prompt */}
            <div className="text-center space-y-2 min-h-[5rem]">
              <p className="text-xl font-bold text-slate-800 leading-relaxed font-sans">
                {prompt}
              </p>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
              <input
                type="text"
                value={word}
                onChange={(e) => setWord(e.target.value)}
                placeholder="Type one word..."
                className="input-field text-center text-lg font-medium placeholder:font-normal"
                autoFocus
              />

              {/* Privacy Toggle */}
              <div className="flex justify-center">
                <div className="bg-slate-100 p-1 rounded-xl flex items-center relative gap-1">
                  <button
                    type="button"
                    onClick={() => setIsPublic(true)}
                    className={`flex items-center gap-1 px-3 py-1.5 rounded-lg text-sm font-medium transition-all ${isPublic ? 'bg-white text-farcaster-700 shadow-sm' : 'text-slate-500 hover:text-slate-700'
                      }`}
                  >
                    <Globe size={14} />
                    Public
                  </button>
                  <button
                    type="button"
                    onClick={() => setIsPublic(false)}
                    className={`flex items-center gap-1 px-3 py-1.5 rounded-lg text-sm font-medium transition-all ${!isPublic ? 'bg-white text-farcaster-700 shadow-sm' : 'text-slate-500 hover:text-slate-700'
                      }`}
                  >
                    <Lock size={14} />
                    Private
                  </button>
                </div>
              </div>

              <button
                type="submit"
                disabled={!word.trim() || isSubmitting}
                className="w-full btn-primary flex items-center justify-center gap-2 py-3 text-lg shadow-farcaster-200/50 shadow-lg"
              >
                <span>Submit</span>
                <Send size={18} />
              </button>
            </form>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
