import { useState } from 'react';
import { useSpacetime } from '../spacetime';
import SimpleWordCloud from './SimpleWordCloud';
import { motion, AnimatePresence } from 'framer-motion';
import { List, Cloud, Globe, Lock, Clock } from 'lucide-react';
import { PROMPTS } from '../prompts';

export default function Profile() {
  const { words, stats, refresh } = useSpacetime();
  const [filter, setFilter] = useState<'all' | 'public' | 'private'>('public');
  const [viewMode, setViewMode] = useState<'list' | 'cloud'>('list');
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [hasRevealedPrivate, setHasRevealedPrivate] = useState(false);

  // Login Screen
  if (!isLoggedIn) {
    return (
      <div className="h-full flex flex-col items-center justify-center p-8 bg-slate-50 relative overflow-hidden">
        {/* Decorative Background */}
        <div className="absolute top-[-50px] right-[-50px] w-64 h-64 bg-farcaster-100 rounded-full blur-3xl opacity-50" />
        <div className="absolute bottom-[-50px] left-[-50px] w-64 h-64 bg-farcaster-200 rounded-full blur-3xl opacity-50" />

        <div className="relative z-10 w-full max-w-sm bg-white p-8 rounded-3xl shadow-xl flex flex-col items-center text-center space-y-6">
          <div className="w-20 h-20 bg-farcaster-50 rounded-2xl flex items-center justify-center mb-2">
            <span className="text-4xl">👋</span>
          </div>
          <div>
            <h2 className="text-2xl font-bold text-slate-900">Welcome Back</h2>
            <p className="text-slate-500 text-sm mt-2">Sign in to view your collection</p>
          </div>

          <button
            onClick={() => setIsLoggedIn(true)}
            className="w-full bg-[#855DCD] hover:bg-[#724BB7] text-white font-bold py-3.5 px-4 rounded-xl transition-all transform active:scale-95 flex items-center justify-center gap-3 shadow-lg shadow-farcaster-200"
          >
            {/* Farcaster Logo Mock */}
            <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
              <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 14c-2.21 0-4-1.79-4-4s1.79-4 4-4 4 1.79 4 4-1.79 4-4 4zm0-6c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2z" />
            </svg>
            Sign in with Farcaster
          </button>

          <p className="text-xs text-slate-400">
            Authentication provided by Farcaster AuthKit
          </p>
        </div>
      </div>
    );
  }

  const handleFilterChange = (newFilter: 'all' | 'public' | 'private') => {
    setFilter(newFilter);
    if (newFilter === 'all' && !hasRevealedPrivate) {
      setHasRevealedPrivate(true);
    }
  };

  const filteredWords = words.filter(w => {
    if (filter === 'public') return w.isPublic;
    if (filter === 'private') return !w.isPublic;
    return true;
  });

  const wordCounts: Record<string, number> = {};
  filteredWords.forEach(w => {
    const txt = w.word.toLowerCase();
    wordCounts[txt] = (wordCounts[txt] || 0) + 1;
  });
  const cloudWords = Object.entries(wordCounts).map(([text, value]) => ({ text, value }));

  const availableFilters = hasRevealedPrivate
    ? ['public', 'all', 'private'] as const
    : ['public', 'all'] as const;

  return (
    <div className="flex flex-col h-full bg-slate-50">
      <div className="bg-white px-6 pt-12 pb-6 rounded-b-3xl shadow-sm z-10 sticky top-0">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold text-farcaster-900">Your Collection</h2>
          <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-farcaster-400 to-farcaster-600 border-2 border-white shadow-sm" />
        </div>

        {/* Stats Grid */}
        <div className={`grid ${hasRevealedPrivate ? 'grid-cols-3' : 'grid-cols-2'} gap-3 mb-6 transition-all duration-300`}>
          {/* Public (Always Visible - Left) */}
          <div className="bg-farcaster-50 p-3 rounded-2xl flex flex-col items-center justify-center text-center transition-transform hover:scale-105">
            <span className="text-2xl font-bold text-farcaster-700">{stats.publicWords}</span>
            <span className="text-[10px] uppercase tracking-wider font-semibold text-farcaster-400 mt-1">Public</span>
          </div>

          {/* Total (Always Visible - Right initially, then Middle) */}
          <div className="bg-farcaster-50 p-3 rounded-2xl flex flex-col items-center justify-center text-center transition-transform hover:scale-105">
            <span className="text-2xl font-bold text-farcaster-700">{stats.totalWords}</span>
            <span className="text-[10px] uppercase tracking-wider font-semibold text-farcaster-400 mt-1">Total</span>
          </div>

          {/* Private (Hidden initially) */}
          {hasRevealedPrivate && (
            <div className="bg-farcaster-50 p-3 rounded-2xl flex flex-col items-center justify-center text-center transition-transform hover:scale-105 animate-fade-in-up">
              <span className="text-2xl font-bold text-farcaster-700">{stats.privateWords}</span>
              <span className="text-[10px] uppercase tracking-wider font-semibold text-farcaster-400 mt-1">Private</span>
            </div>
          )}
        </div>

        {/* Controls */}
        <div className="flex justify-between items-center">
          {/* Filter Tabs */}
          <div className="bg-slate-100 p-1 rounded-xl flex">
            {availableFilters.map((f) => (
              <button
                key={f}
                onClick={() => handleFilterChange(f)}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold capitalize transition-all ${filter === f ? 'bg-white text-farcaster-700 shadow-sm' : 'text-slate-400 hover:text-slate-600'
                  }`}
              >
                {f}
              </button>
            ))}
          </div>

          {/* View Toggle */}
          <div className="flex gap-1 bg-slate-100 p-1 rounded-xl">
            <button
              onClick={() => setViewMode('list')}
              className={`p-1.5 rounded-lg transition-all ${viewMode === 'list' ? 'bg-white text-farcaster-700 shadow-sm' : 'text-slate-400'}`}
            >
              <List size={18} />
            </button>
            <button
              onClick={() => setViewMode('cloud')}
              className={`p-1.5 rounded-lg transition-all ${viewMode === 'cloud' ? 'bg-white text-farcaster-700 shadow-sm' : 'text-slate-400'}`}
            >
              <Cloud size={18} />
            </button>
          </div>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto relative p-4 pb-24">
        <AnimatePresence mode="wait">
          {viewMode === 'list' ? (
            <motion.div
              key="list"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 20 }}
              className="space-y-3"
            >
              {filteredWords.length === 0 && (
                <div className="text-center py-12 text-slate-400 text-sm">No words found.</div>
              )}
              {filteredWords.map((entry) => (
                <motion.div
                  key={entry.id}
                  layout
                  className="bg-white p-4 rounded-xl shadow-sm border border-slate-100 flex justify-between items-center group hover:border-farcaster-200 transition-colors"
                >
                  <div className="flex flex-col gap-1 overflow-hidden">
                    <span className="text-lg font-bold text-slate-800 break-words">{entry.word.toLowerCase()}</span>
                    <span className="text-xs text-slate-400 truncate max-w-[200px]">
                      {PROMPTS[entry.promptId] || 'Unknown prompt'}
                    </span>
                  </div>
                  <div className="flex flex-col items-end gap-2 pl-4 shrink-0">
                    <span className={`text-[10px] font-medium px-2 py-0.5 rounded-full flex items-center gap-1 ${entry.isPublic
                      ? 'bg-farcaster-50 text-farcaster-600'
                      : 'bg-slate-100 text-slate-500'
                      }`}>
                      {entry.isPublic ? <Globe size={10} /> : <Lock size={10} />}
                      {entry.isPublic ? 'Public' : 'Private'}
                    </span>
                    <span className="text-[10px] text-slate-300 flex items-center gap-1">
                      <Clock size={10} />
                      {new Date(entry.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>
                  </div>
                </motion.div>
              ))}
            </motion.div>
          ) : (
            <motion.div
              key="cloud"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="h-full min-h-[300px]"
            >
              <SimpleWordCloud words={cloudWords} onCloudClick={() => refresh()} />
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
