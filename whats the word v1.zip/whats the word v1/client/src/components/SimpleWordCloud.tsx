import { useEffect, useRef, useState } from 'react';
import cloud from 'd3-cloud';

// Custom Farcaster palette
const FARCASTER_COLORS = ['#643EF5', '#7C3AED', '#8B5CF6', '#A78BFA', '#C4B5FD', '#4C1D95'];

interface Word {
  text: string;
  value: number;
}

interface WordCloudProps {
  words: Word[];
  width?: number;
  height?: number;
  onCloudClick?: () => void;
}

export default function SimpleWordCloud({ words, onCloudClick }: WordCloudProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const [cloudWords, setCloudWords] = useState<any[]>([]);
  const [dimensions, setDimensions] = useState({ width: 0, height: 0 });

  useEffect(() => {
    if (!containerRef.current) return;

    // Observer for resize
    const observer = new ResizeObserver((entries) => {
      const entry = entries[0];
      if (entry) {
        setDimensions({
          width: entry.contentRect.width,
          height: entry.contentRect.height
        });
      }
    });

    observer.observe(containerRef.current);
    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    if (dimensions.width === 0 || dimensions.height === 0 || words.length === 0) return;

    // Simple normalization of font size
    const maxVal = Math.max(...words.map(w => w.value));
    const minVal = Math.min(...words.map(w => w.value));

    const fontSizeScale = (value: number) => {
      if (maxVal === minVal) return 30;
      return 20 + ((value - minVal) / (maxVal - minVal)) * 30; // 20px to 50px
    };

    const layout = cloud()
      .size([dimensions.width, dimensions.height])
      .words(words.map(d => ({ text: d.text, size: fontSizeScale(d.value), value: d.value })))
      .padding(5)
      .rotate(() => (~~(Math.random() * 2) * 90))
      .font("Inter")
      .fontSize(d => d.size as number)
      .on("end", (computedWords) => {
        setCloudWords(computedWords);
      });

    layout.start();
  }, [words, dimensions]);

  return (
    <div
      ref={containerRef}
      onClick={onCloudClick}
      className="w-full h-full relative overflow-hidden cursor-pointer active:scale-[0.99] transition-transform"
      title="Tap to refresh words"
    >
      <svg width={dimensions.width} height={dimensions.height}>
        <g transform={`translate(${dimensions.width / 2},${dimensions.height / 2})`}>
          {cloudWords.map((w, i) => (
            <text
              key={`${w.text}-${i}`}
              style={{
                fontFamily: 'Inter',
                fontSize: `${w.size}px`,
                fontWeight: 'bold',
                fill: FARCASTER_COLORS[i % FARCASTER_COLORS.length],
                transition: 'all 0.5s ease',
                cursor: 'default'
              }}
              textAnchor="middle"
              transform={`translate(${w.x},${w.y})rotate(${w.rotate})`}
            >
              {w.text}
            </text>
          ))}
        </g>
      </svg>
    </div>
  );
}
