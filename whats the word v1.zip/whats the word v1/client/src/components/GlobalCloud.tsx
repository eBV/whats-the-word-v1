import { useSpacetime } from '../spacetime';
import SimpleWordCloud from './SimpleWordCloud';
import { motion } from 'framer-motion';

export default function GlobalCloud() {
  const { words, stats, refresh } = useSpacetime();

  const publicWords = words.filter(w => w.isPublic);

  const wordCounts: Record<string, number> = {};
  publicWords.forEach(w => {
    const txt = w.word.toLowerCase();
    wordCounts[txt] = (wordCounts[txt] || 0) + 1;
  });

  const cloudWords = Object.entries(wordCounts).map(([text, value]) => ({
    text,
    value,
  }));

  return (
    <div className="flex flex-col h-full bg-white">
      <div className="px-6 pt-12 pb-2 border-b border-farcaster-50">
        <h2 className="text-xl font-bold text-farcaster-900 mb-2">Global Words</h2>
        <div className="flex gap-4 text-xs text-slate-500 font-medium pb-2">
          <div className="bg-farcaster-50 px-3 py-1.5 rounded-lg text-farcaster-700">
            <span className="font-bold">{stats.publicWords}</span> expressed
          </div>
          <div className="bg-farcaster-50 px-3 py-1.5 rounded-lg text-farcaster-700">
            <span className="font-bold">{cloudWords.length}</span> unique
          </div>
        </div>
      </div>

      <div className="flex-1 w-full overflow-hidden relative p-4">
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5 }}
          className="w-full h-full"
        >
          {cloudWords.length > 0 ? (
            <SimpleWordCloud words={cloudWords} onCloudClick={() => refresh()} />
          ) : (
            <div className="flex items-center justify-center h-full text-slate-400">
              No words yet... be the first!
            </div>
          )}
        </motion.div>
      </div>
    </div>
  );
}
