import { Outlet, NavLink, useLocation } from 'react-router-dom';
import { Pencil, Globe, User } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

export default function Layout() {
  const location = useLocation();

  return (
    <div className="h-screen bg-slate-50 flex flex-col max-w-md mx-auto relative shadow-2xl overflow-hidden">
      <main className="flex-1 overflow-y-auto pb-20 relative bg-gradient-to-br from-farcaster-50 to-white">
        <AnimatePresence mode="wait">
          <motion.div
            key={location.pathname}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.2 }}
            className="h-full"
          >
            <Outlet />
          </motion.div>
        </AnimatePresence>
      </main>

      <nav className="absolute bottom-0 left-0 right-0 bg-white/90 backdrop-blur-lg border-t border-slate-100 z-50 pb-safe">
        <div className="flex justify-around items-center h-16">
          <NavLink
            to="/"
            className={({ isActive }) =>
              `flex flex-col items-center justify-center w-full h-full space-y-1 transition-colors ${isActive ? 'text-farcaster-600' : 'text-slate-400 hover:text-slate-600'
              }`
            }
          >
            <Pencil size={24} strokeWidth={2.5} />
            <span className="text-[10px] font-medium">Write</span>
          </NavLink>

          <NavLink
            to="/global"
            className={({ isActive }) =>
              `flex flex-col items-center justify-center w-full h-full space-y-1 transition-colors ${isActive ? 'text-farcaster-600' : 'text-slate-400 hover:text-slate-600'
              }`
            }
          >
            <Globe size={24} strokeWidth={2.5} />
            <span className="text-[10px] font-medium">Global</span>
          </NavLink>

          <NavLink
            to="/profile"
            className={({ isActive }) =>
              `flex flex-col items-center justify-center w-full h-full space-y-1 transition-colors ${isActive ? 'text-farcaster-600' : 'text-slate-400 hover:text-slate-600'
              }`
            }
          >
            <User size={24} strokeWidth={2.5} />
            <span className="text-[10px] font-medium">Profile</span>
          </NavLink>
        </div>
      </nav>
    </div>
  );
}
