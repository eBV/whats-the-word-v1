// Mock SpacetimeDB client since we can't run the backend locally without the CLI
import { useState, useEffect } from 'react';

export interface WordEntry {
  id: string;
  word: string;
  isPublic: boolean;
  timestamp: number;
  promptId: number;
}

export interface UserStats {
  totalWords: number;
  publicWords: number;
  privateWords: number;
  dailyCount: number;
}

// In-memory store
const STORE_KEY = 'wordup_store';

interface Store {
  words: WordEntry[];
  dailyCount: { date: string; count: number };
}

const getStore = (): Store => {
  const data = localStorage.getItem(STORE_KEY);
  if (data) return JSON.parse(data);
  return { words: [], dailyCount: { date: new Date().toDateString(), count: 0 } };
};

const saveStore = (store: Store) => {
  localStorage.setItem(STORE_KEY, JSON.stringify(store));
};

export const useSpacetime = () => {
  const [words, setWords] = useState<WordEntry[]>([]);
  const [stats, setStats] = useState<UserStats>({ totalWords: 0, publicWords: 0, privateWords: 0, dailyCount: 0 });

  useEffect(() => {
    refresh();
    // Removed polling interval as per user request
    // const interval = setInterval(refresh, 1000); 
    // return () => clearInterval(interval);
  }, []);

  const refresh = () => {
    const store = getStore();
    // Check execution date reset
    const today = new Date().toDateString();
    if (store.dailyCount.date !== today) {
      store.dailyCount = { date: today, count: 0 };
      saveStore(store);
    }

    setWords(store.words);
    setStats({
      totalWords: store.words.length,
      publicWords: store.words.filter(w => w.isPublic).length,
      privateWords: store.words.filter(w => !w.isPublic).length,
      dailyCount: store.dailyCount.count,
    });
  };

  const submitWord = async (word: string, isPublic: boolean, promptId: number) => {
    const store = getStore();
    const today = new Date().toDateString();

    if (store.dailyCount.date !== today) {
      store.dailyCount = { date: today, count: 0 };
    }

    if (store.dailyCount.count >= 20) {
      throw new Error("Daily limit reached");
    }

    const newWord: WordEntry = {
      id: Math.random().toString(36).substr(2, 9),
      word,
      isPublic,
      timestamp: Date.now(),
      promptId
    };

    store.words.unshift(newWord);
    store.dailyCount.count++;

    saveStore(store);
    refresh();
    return newWord;
  };

  return {
    words,
    stats,
    submitWord,
    refresh
  };
};
