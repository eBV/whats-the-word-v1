use spacetimedb::{spacetimedb, Identity, SpacetimeType, Timestamp, ReducerContext};

#[spacetimedb(table)]
pub struct User {
    #[primarykey]
    pub id: Identity,
    pub last_seen: Timestamp,
}

#[spacetimedb(table)]
pub struct WordEntry {
    #[autoinc]
    #[primarykey]
    pub id: u64,
    pub user_id: Identity,
    pub word: String,
    pub is_public: bool,
    pub ts: Timestamp,
    pub prompt_id: u32,
}

#[spacetimedb(table)]
pub struct DailySubmission {
    #[primarykey]
    pub user_id: Identity,
    pub count: u8,
    pub last_submission_date: String, // ISO date string YYYY-MM-DD
}

fn get_today_string(ts: Timestamp) -> String {
    // Simplified date extraction for demo purposes
    // A real implementation would use a chrono crate or similar logic
    // We'll just assume a string is passed or computed correctly
    // Since we don't have chrono here easily without deps, we'll mock this part logic 
    // or rely on client passing date? No, server authoritative.
    // For this generated file, we'll keep it simple/conceptual.
    // Assuming Timestamp can be formatted.
    format!("{}", ts.micros / (1000 * 1000 * 60 * 60 * 24)) // days since epoch
}

#[spacetimedb(reducer)]
pub fn submit_word(ctx: ReducerContext, word: String, is_public: bool, prompt_id: u32) {
    let user_id = ctx.sender;
    let ts = ctx.timestamp;
    let today = get_today_string(ts);

    // Update user last seen
    if let Some(mut user) = User::filter_by_id(&user_id) {
        user.last_seen = ts;
        User::update_by_id(&user_id, user);
    } else {
        User::insert(User { id: user_id, last_seen: ts });
    }

    // Check daily limit
    let mut current_count = 0;
    if let Some(mut submission) = DailySubmission::filter_by_user_id(&user_id) {
        if submission.last_submission_date != today {
            // New day, reset
            submission.last_submission_date = today.clone();
            submission.count = 0;
        }
        
        if submission.count >= 20 {
            log::error!("Daily limit reached");
            return; // Or panic/error
        }
        current_count = submission.count + 1;
        submission.count = current_count;
        DailySubmission::update_by_user_id(&user_id, submission);
    } else {
        DailySubmission::insert(DailySubmission {
            user_id,
            count: 1,
            last_submission_date: today,
        });
        current_count = 1;
    }

    // Insert word
    WordEntry::insert(WordEntry {
        id: 0, // autoinc
        user_id,
        word,
        is_public,
        ts,
        prompt_id,
    });
}
